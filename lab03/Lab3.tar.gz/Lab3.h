#include<iostream>
#include<cassert>
#include<stack>

using namespace std;

template<typename t>
class TwoStackFixed
{
    private:
    t* vals;
    t* maxtop;
    t* top1;
    t* top2;
    int sz;
    
    public:
    //creats an array in the heap and stacks are empty so they point to 1 oustide of the array
    TwoStackFixed(int size, int maxtop)
    : vals(new t[size]), maxtop(&vals[maxtop]), top1(vals - 1), top2(vals + size), sz(size)
    {}
    
    //deletes array allocated with new
    ~TwoStackFixed()
    {
        delete[] vals;
    }
    
    //adds element to next spot in the array through the top1 pointer if space is available
    void pushStack1(t value)
    {
        if(isFullStack1())
        {
            cout << "stack 1 is full. can not add element: " << value << endl;
            return;
        }
        ++top1;
        *top1 = value;
        display(); cout << endl;
    }
    
    //adds element to next spot in the array through the top2 pointer if space is available
    void pushStack2(t value)
    {
        if(isFullStack2())
        {
            cout << "stack 2 is full. can not add element: " << value << endl;
            return;
        }
        --top2;
        *top2 = value;
        display(); cout << endl;
    }
    
    //decreases the size of the stack by moving the pointer
    t popStack1()
    {
        assert(!isEmptyStack1());
        t out = *top1;
        --top1;
        return out;
    }
    
    //decreases the size of the stack by moving the pointer
    t popStack2()
    {
        assert(!isEmptyStack2());
        t out = *top2;
        ++top2;
        return out;
    }
    
    bool isFullStack1()
    {
        return (top1 == maxtop);
    }
    
    bool isFullStack2()
    {
        return (top2 - 1 == maxtop);
    }
    
    bool isEmptyStack1()
    {
        return (top1 == vals - 1);
    }
    
    bool isEmptyStack2()
    {
        return (top2 == vals + sz);
    }
    
    void display()
    {
        if(!isEmptyStack1())//empty stack check
        {
            for(auto temp = vals; temp != top1 + 1; ++temp)
            {
                cout << *temp << ' ';
            }
        }
        for(auto temp = top1 + 1; temp != top2; ++temp)
        {
            cout << ' ' << ' ';
        }
        if(!isEmptyStack2())//empty stack check
        {
            cout << *top2;
            for(auto temp = top2 + 1; temp != vals + sz; ++temp)
            {
                cout << ' ' << *temp;
            }
        }
    }
};

template<typename T>
class TwoStackOptimal
{
    private:
    T* vals;
    T* top1;
    T* top2;
    int sz;
    
    public:
    //creats an array in the heap and stacks are empty so they point to 1 oustide of the array
    TwoStackOptimal(int size)
    : vals(new T[size]), top1(vals - 1), top2(vals + size), sz(size)
    {}
    
    
    //deletes array allocated with new
    ~TwoStackOptimal()
    {
        delete[] vals;
    }
    
    //adds element to next spot in the array through the top1 pointer if space is available
    void pushStack1(T value)
    {
        if(isFullStack1())
        {
            cout << "stack 1 is full. can not add element: " << value << endl;
            return;
        }
        ++top1;
        *top1 = value;
        display(); cout << endl;
    }
    
    //adds element to next spot in the array through the top pointer if space is available
    void pushStack2(T value)
    {
        if(isFullStack2())
        {
            cout << "stack 2 is full. can not add element: " << value << endl;
            return;
        }
        --top2;
        *top2 = value;
        display(); cout << endl;
    }
    
    //decreases the size of the stack by moving the pointer
    T popStack1()
    {
        assert(!isEmptyStack1());
        T out = *top1;
        --top1;
        return out;
    }
    
    //decreases the size of the stack by moving the pointer
    T popStack2()
    {
        assert(!isEmptyStack2());
        T out = *top2;
        ++top2;
        return out;
    }
    
    bool isFullStack1()
    {
        return top1 + 1 == top2;
    }
    
    bool isFullStack2()
    {
        return top2 - 1 == top1;
    }
    
    bool isEmptyStack1()
    {
        return (top1 == vals - 1);
    }
    
    bool isEmptyStack2()
    {
        return (top2 == vals + sz);
    }
    
    void display()
    {
        if(!isEmptyStack1())
        {
            for(auto temp = vals; temp != top1 + 1; ++temp)//empty stack check
            {
                cout << *temp << ' ';
            }
        }
        for(auto temp = top1 + 1; temp != top2; ++temp)
        {
            cout << ' ' << ' ';
        }
        if(!isEmptyStack2())//empty stack check
        {
            cout << *top2;
            for(auto temp = top2 + 1; temp != vals + sz; ++temp)
            {
                cout << ' ' << *temp;
            }
        }
    }
};

template<typename Type>
void showTowerStates(int n, stack<Type>& A, stack<Type>& B, stack<Type>& C)
{
    if((B.empty() && C.empty()) || !A.empty() && ((B.empty() || A.top() < B.top())) && (C.empty() || A.top() < C.top()))
    {
        C.push(A.top());
        A.pop();
        cout << "Moved " << C.top() << " from peg A to C" << endl;
        if(A.empty() && B.empty())
        {
            return;
        }
        else if(A.empty() && C.empty())
        {
            showTowerStates(n, A,B, C);
            return;
        }
        else if(B.empty())
        {
            B.push(A.top());
            A.pop();
            cout << "Moved " << B.top() << " from peg A to B" << endl;
        }
        else if(A.empty())
        {
            A.push(B.top());
            B.pop();
            cout << "Moved " << A.top() << " from peg B to A" << endl;
        }
        else if(A.top() < B.top())
        {
            B.push(A.top());
            A.pop();
            cout << "Moved " << B.top() << " from peg A to B" << endl;
        }
        else
        {
            A.push(B.top());
            B.pop();
            cout << "Moved " << A.top() << " from peg B to A" << endl;
        }
    }
    else if((A.empty() && B.empty()) || !C.empty() && ((A.empty() || C.top() < A.top()) && (B.empty() || C.top() < B.top())))
    {
        B.push(C.top());
        C.pop();
        cout << "Moved " << B.top() << " from peg C to B" << endl;
        if(A.empty() && C.empty())
        {
            cout << "test" << endl;
            showTowerStates(n, A,B, C);
            return;
        }
        else if(C.empty())
        {
            C.push(A.top());
            A.pop();
            cout << "Moved " << C.top() << " from peg A to C" << endl;
        }
        else if(A.empty())
        {
            A.push(C.top());
            C.pop();
            cout << "Moved " << A.top() << " from peg C to A" << endl;
        }
        else if(A.top() < C.top())
        {
            C.push(A.top());
            A.pop();
            cout << "Moved " << C.top() << " from peg A to C" << endl;
        }
        else
        {
            A.push(C.top());
            C.pop();
            cout << "Moved " << A.top() << " from peg C to A" << endl;
        }
    }
    else
    {
        A.push(B.top());
        B.pop();
        cout << "Moved " << A.top() << " from peg B to A" << endl;
        if(A.empty() && C.empty())
        {
            showTowerStates(n, A,B, C);
            return;
        }
        else if(B.empty())
        {
            B.push(C.top());
            C.pop();
            cout << "Moved " << B.top() << " from peg C to B" << endl;
        }
        else if(C.empty())
        {
            C.push(B.top());
            B.pop();
            cout << "Moved " << C.top() << " from peg B to C" << endl;
        }
        else if(C.top() < B.top())
        {
            B.push(C.top());
            C.pop();
            cout << "Moved " << B.top() << " from peg C to B" << endl;
        }
        else
        {
            C.push(B.top());
            B.pop();
            cout << "Moved " << C.top() << " from peg B to C" << endl;
        }
    }
    showTowerStates(n, A,B, C);
}








