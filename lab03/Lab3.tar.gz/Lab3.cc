// Preston Giorgianni
// 861161781
// 4/20/14
#include<iostream>
#include"Lab3.h"

using namespace std;

void fixedStackTest()
{
    cout << "Fixed stack with ints" << endl;
    TwoStackFixed<int> test(10 , 5);
    for(int i = 0; i < 15; ++i)
    {
        test.pushStack1(i);
        test.display(); cout << endl;
    }
    for(int i = 0; i < 9; ++i)
    {
        test.pushStack2(i);
        test.display(); cout << endl;
    }
    test.display(); cout << endl;
    cout << test.popStack1() << endl;
    cout << test.popStack1() << endl;
    cout << test.popStack1() << endl;
    cout << test.popStack1() << endl;
    cout << test.popStack1() << endl;
    cout << test.popStack1() << endl;
    // cout << test.popStack1() << endl;
    test.display(); cout << endl;
    cout << test.popStack2() << endl;
    cout << test.popStack2() << endl;
    cout << test.popStack2() << endl;
    cout << test.popStack2() << endl;
    // cout << test.popStack2() << endl;
    test.display(); cout << endl;
    cout << "------------------------------------------------------------------" << endl;
    cout << "Fixed stack with strings" << endl;
    TwoStackFixed<string> test2(5, 1);
    test2.pushStack1("one");
    test2.pushStack1("two");
    test2.pushStack2("one");
    test2.pushStack2("two");
    test2.pushStack2("three");
    test2.pushStack2("four");
    cout << test2.popStack1() << endl;
    cout << test2.popStack2() << endl;
    cout << test2.popStack1() << endl;
    test2.display(); cout << endl;
    cout << "------------------------------------------------------------------" << endl;
}

void optimalTest()
{
    cout << "Optimal stacks with ints" << endl;
    TwoStackOptimal<int> test(10);
    for(int i = 0; i < 6; ++i)
    {
        test.pushStack1(i);
    }
    for(int i = 0; i < 6; ++i)
    {
        test.pushStack2(i);
    }
    test.pushStack1(2);
    test.pushStack1(1);
    test.display(); cout << endl;
    cout << test.popStack1() << endl;
    cout << test.popStack1() << endl;
    cout << test.popStack1() << endl;
    cout << test.popStack1() << endl;
    cout << test.popStack1() << endl;
    cout << test.popStack1() << endl;
    // cout << test.popStack1() << endl;
    test.display(); cout << endl;
    cout << test.popStack2() << endl;
    cout << test.popStack2() << endl;
    cout << test.popStack2() << endl;
    cout << test.popStack2() << endl;
    // cout << test.popStack2() << endl;
    test.display(); cout << endl;
    cout << "------------------------------------------------------------------" << endl;
    cout << "Optimal stacks with strings" << endl;
    TwoStackOptimal<string> test2(5);
    test2.pushStack1("one");
    test2.pushStack1("two");
    test2.pushStack2("one");
    test2.pushStack2("two");
    test2.pushStack2("three");
    test2.pushStack2("four");
    test2.display(); cout << endl;
    cout << test2.popStack1() << endl;
    cout << test2.popStack2() << endl;
    cout << test2.popStack1() << endl;
    test2.display(); cout << endl;
    cout << "------------------------------------------------------------------" << endl;
}

void tower3ints()
{
    stack<int> A;
    stack<int> B;
    stack<int> C;
    for(int i = 3; i > 0; --i)
    {
        A.push(i);
    }
    showTowerStates(3, A,B, C);
    cout << "------------------------------------------------------------------" << endl;
}

void tower4ints()
{
    stack<int> A;
    stack<int> B;
    stack<int> C;
    for(int i = 4; i > 0; --i)
    {
        A.push(i);
    }
    showTowerStates(4, A,B, C);
    cout << "------------------------------------------------------------------" << endl;
}

void tower5ints()
{
    stack<int> A;
    stack<int> B;
    stack<int> C;
    for(int i = 5; i > 0; --i)
    {
        A.push(i);
    }
    showTowerStates(5, A,B, C);
    cout << "------------------------------------------------------------------" << endl;
}

void towerChar()
{
    stack<char> A;
    stack<char> B;
    stack<char> C;
    A.push('c'); A.push('b'); A.push('a');
    showTowerStates(3, A, B , C);
    cout << "------------------------------------------------------------------" << endl;
}

int main()
{
    fixedStackTest();
    optimalTest();
    tower3ints();
    tower4ints();
    tower5ints();
    towerChar();
    return 0;
}